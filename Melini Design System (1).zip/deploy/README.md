# Deploy — drop-in v2 pour le repo melini-site

3 fichiers à committer **à la racine** de `github.com/JeSuisThomas/melini-site`, en remplacement des existants.

| Fichier | Remplace |
|---|---|
| `deploy/index.html` | `index.html` |
| `deploy/style.css` | `style.css` |
| `deploy/script.js` | `script.js` |

## Procédure GitHub (la plus simple)

1. Dans GitHub, ouvre `melini-site/index.html` → bouton crayon (Edit) → colle le contenu de `deploy/index.html` → Commit.
2. Pareil pour `style.css` et `script.js`.
3. Si tu déploies via GitHub Pages / Netlify / Vercel, ça se met à jour automatiquement après le commit.

## Procédure Git locale

```bash
cd /chemin/vers/melini-site
# remplace les 3 fichiers
cp <ce-projet>/deploy/index.html .
cp <ce-projet>/deploy/style.css .
cp <ce-projet>/deploy/script.js .

git add index.html style.css script.js
git commit -m "v2 design : hero éditorial, chapitres romains, interlude, contact sculpté"
git push
```

## Compatibilité

- ✅ Mêmes IDs CMS conservés (`cms-hero-img`, `cms-hero-sub`, `cms-bandeau`, `cms-histoire-img`, `cms-h-lundi/mardi/dimanche`, `cms-carousel`) → `script.js` charge `/content/site.json` exactement comme avant. Ton CMS continue de fonctionner.
- ✅ Mêmes images (`images/plante_melini.jpg`, `images/Anjel_chaussure.jpg`) → aucun déplacement nécessaire.
- ✅ SEO préservé : `<title>`, meta description, OG, JSON-LD `ShoeStore`, `<link rel="canonical">`, balises sémantiques (`<header>`, `<section>`, `<nav>`, `<footer>`), alt sur toutes les images, lazy-loading iframe.
- ✅ Fonts identiques (Cormorant Garamond + Outfit via Google Fonts).
- ✅ Iframe Google Maps conservée (filtre grayscale doux pour s'intégrer au noir).

## Différences visuelles vs v1

- Hero composition split + téléphone visible + horaires du jour (côté droit desktop)
- Chapitres romains I → VI dans cercle rosé
- Drop cap rosée sur le lead d'About + cite flottante "Anjel, fondatrice"
- Disclaimer collection en encadré crème ornementé
- Carrousel rythmé (items décalés en Y, pattern 3)
- **Interlude pleine largeur** (image 21:9 entre Collection et Marques)
- Filets verticaux haut/bas sur Marques + mention "Premium · 100 — 200 €"
- Cartes témoignages avec avatar initiale rosé
- Contact noir asymétrique, téléphone en serif italique 22px
- Footer 3 colonnes avec M central
