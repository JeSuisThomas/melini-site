# Melini — UI Kit · Site vitrine

Recréation haute fidélité du site `melini.be`. Source : `github.com/JeSuisThomas/melini-site` (tokens CSS conservés à l'identique).

## Composants (components.jsx)

| Component | Usage |
|---|---|
| `<Nav />` | Pilule flottante, glass → solid au scroll |
| `<Hero />` | Hero plein écran cinématique avec photo boutique |
| `<Bandeau>{...}</Bandeau>` | Annonce contextuelle rose, 11px majuscules espacées |
| `<About />` | Histoire d'Anjel — image 3/4 + texte + stats |
| `<Collection />` | Disclaimer + carrousel infini 50s, pause au hover |
| `<Marques />` | Liste serif espacée par middot, fond crème |
| `<Testimonial quote name source />` | Carte double-bezel crème + blanc |
| `<Testimonials />` | Grid 3 colonnes responsive |
| `<Social />` | CTA outline rose + lien Facebook |
| `<Contact />` | Section noire, info + map placeholder, CTA appel/itinéraire |
| `<Footer />` | Copyright minimal noir |

## Pour utiliser

Charger React + Babel, puis `style.css`, puis `components.jsx`. Voir `index.html`.

Les composants exposent `window.{Nav, Hero, ...}` pour pouvoir être chargés dans plusieurs scripts Babel sans collision de scope.
