/* global React */
const { useState, useEffect, useRef } = React;

function Nav({ onCta }) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <nav className={`uk-nav ${scrolled ? 'scrolled' : ''}`}>
      <a href="#" className="logo">MELINI</a>
      <div className="links">
        <a href="#histoire">Notre histoire</a>
        <a href="#selection">Collection</a>
        <a href="#marques">Marques</a>
        <a href="#contact" className="cta" onClick={onCta}>Nous trouver</a>
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <header className="uk-hero">
      <div className="uk-hero-image">
        <img src="../../assets/plante-melini.jpg" alt="Melini" />
      </div>
      <div className="uk-hero-content">
        <p className="uk-hero-loc">Uccle, Bruxelles</p>
        <h1>À chaque pas,<br/><em>votre signature</em></h1>
        <div className="uk-hero-line"></div>
        <p className="uk-hero-sub">Melini · Chaussures & sacs</p>
        <a href="#contact" className="btn-light uk-hero-btn">Nous rendre visite</a>
      </div>
      <div className="uk-hero-scroll"><div className="ln"></div><span>Explorer</span></div>
    </header>
  );
}

function Bandeau({ children }) {
  return <div className="bandeau">{children}</div>;
}

function About() {
  return (
    <section className="uk-section" id="histoire">
      <div className="uk-about">
        <div className="uk-about-image">
          <div className="uk-about-image-inner">
            <img src="../../assets/anjel-chaussure.jpg" alt="Anjel" />
          </div>
        </div>
        <div>
          <p className="uk-eyebrow">Notre histoire</p>
          <h2 className="uk-title">Melini, c'est avant tout<br/>l'histoire d'Anjel</h2>
          <p className="uk-text">Passionnée depuis toujours, Anjel consacre sa vie à l'art de bien chausser les femmes. Formée au sein d'enseignes prestigieuses, elle a cultivé l'amour des belles matières, des coupes impeccables et du détail qui fait toute la différence.</p>
          <p className="uk-text" style={{marginTop:16}}>En 2016, elle ouvre Melini sur la Chaussée d'Alsemberg, un espace chaleureux pensé pour le contact humain, loin des codes froids de la vente traditionnelle.</p>
          <p className="uk-text" style={{marginTop:16, fontStyle:'italic', color:'var(--text-muted)'}}>Pousser la porte, c'est prendre le temps de découvrir la sélection à votre rythme.</p>
          <div className="uk-stats">
            <div className="uk-stat"><div className="num">40</div><div className="lab">Années d'expérience</div></div>
            <div className="uk-stat"><div className="num">20+</div><div className="lab">Marques européennes</div></div>
            <div className="uk-stat"><div className="num">2016</div><div className="lab">Ouverture</div></div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Collection() {
  const seeds = ['shoe1','shoe2','bag1','shoe3','shoe4','bag2','shoe5','shoe6','bag3','shoe7','shoe8','shoe9'];
  const items = [...seeds, ...seeds];
  const [paused, setPaused] = useState(false);
  return (
    <section className="uk-section uk-collection" id="selection">
      <p className="uk-eyebrow">Collection</p>
      <h2 className="uk-title">Un aperçu de nos collections</h2>
      <div className="uk-disclaimer" style={{maxWidth:520, margin:'0 auto 52px'}}>
        Cette sélection ne représente qu'une partie de nos articles en boutique. Venez nous rendre visite pour découvrir l'ensemble de la collection.
      </div>
      <div className="uk-carousel-wrap">
        <div
          className={`uk-carousel ${paused ? 'paused' : ''}`}
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          {items.map((s, i) => (
            <div key={i} className="uk-carousel-item">
              <div className="uk-carousel-img">
                <img src={`https://picsum.photos/seed/melini-${s}-${i}/300/400`} alt="" />
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="uk-carousel-cta">
        <a href="#contact" className="btn-primary">Découvrir toute la collection en boutique</a>
      </div>
    </section>
  );
}

function Marques() {
  return (
    <section className="uk-section uk-marques" id="marques">
      <p className="uk-eyebrow">Nos marques</p>
      <p className="uk-marques-line">NeroGiardini · Hispanitas · Gabor · Unisa · Liu Jo · Etrier · Regarde le Ciel · Tamaris · Ángel Alarcón · Les Tropéziennes · Pedro Miralles · Scapa · Noa Harmon · Sun68 · Oh My Sandals · Hee · DLS · Kaotiko · Wirth · Shepherd · Victoria</p>
      <p className="uk-marques-count">Plus de 20 maisons européennes sélectionnées avec exigence</p>
    </section>
  );
}

function Testimonial({ quote, name, source }) {
  return (
    <div className="card-bezel">
      <div className="card-bezel-inner uk-testi-quote">
        <blockquote>{quote}</blockquote>
        <cite>{name}</cite>
        <span className="source">{source}</span>
      </div>
    </div>
  );
}

function Testimonials() {
  return (
    <section className="uk-section uk-testi">
      <p className="uk-eyebrow">Ce qu'elles en disent</p>
      <h2 className="uk-title">La parole à nos clientes</h2>
      <div className="uk-testi-grid">
        <Testimonial
          quote="Je recommande cette boutique les yeux fermés ! On y trouve un très beau choix de chaussures et d'articles de maroquinerie de qualité. L'accueil est chaleureux et les conseils toujours professionnels."
          name="Nadine V." source="Avis Facebook" />
        <Testimonial
          quote="Il m'a été rare de vivre un accueil aussi chaleureux ! Je suis sortie de la boutique d'Anjel avec LE sac idéal. Merci pour vos précieux conseils."
          name="Ada W." source="Avis Google" />
        <Testimonial
          quote="J'y retourne car la dame est extrêmement soucieuse de la satisfaction du client. Ma fille y vient pour la qualité des chaussures et les conseils."
          name="G.H." source="Avis Google" />
      </div>
    </section>
  );
}

function Social() {
  return (
    <section className="uk-section uk-social">
      <p className="uk-eyebrow">Suivez-nous</p>
      <h2 className="uk-title">Retrouvez-nous sur Facebook</h2>
      <p className="uk-text" style={{margin:'0 auto'}}>Nouveautés, coups de coeur et coulisses de la boutique.</p>
      <a href="#" className="btn-outline" style={{marginTop:32}}>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
        Melini sur Facebook
      </a>
    </section>
  );
}

function Contact() {
  return (
    <section className="uk-section uk-contact" id="contact">
      <div className="uk-contact-inner">
        <div>
          <p className="uk-eyebrow">Nous trouver</p>
          <h2>Rendez-nous visite</h2>
          <div className="uk-contact-info">
            <div className="uk-contact-block">
              <h4>Adresse</h4>
              <p><a href="#">Chaussée d'Alsemberg 817<br/>1180 Uccle, Bruxelles</a></p>
            </div>
            <div className="uk-contact-block">
              <h4>Horaires</h4>
              <table className="uk-horaires">
                <tbody>
                  <tr><td>Lundi</td><td>14h00 · 18h30</td></tr>
                  <tr><td>Mardi à Samedi</td><td>10h00 · 18h30</td></tr>
                  <tr><td>Dimanche</td><td>Fermé</td></tr>
                </tbody>
              </table>
            </div>
            <div className="uk-contact-block">
              <h4>Téléphone</h4>
              <a href="tel:023777880" style={{fontSize:18, color:'#fff', fontFamily:'var(--serif)'}}>02 377 78 80</a>
            </div>
            <div className="uk-contact-actions">
              <a href="#" className="uk-cbtn uk-cbtn-pri">
                <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
                Appeler
              </a>
              <a href="#" className="uk-cbtn uk-cbtn-sec">
                <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                Itinéraire
              </a>
            </div>
          </div>
        </div>
        <div className="uk-contact-map">
          <div className="grid"></div>
          <div className="road"></div>
          <div className="pin">
            <svg width="32" height="32" fill="#D4A99A" viewBox="0 0 24 24"><path d="M12 2C7.6 2 4 5.6 4 10c0 5.5 8 12 8 12s8-6.5 8-12c0-4.4-3.6-8-8-8zm0 11a3 3 0 110-6 3 3 0 010 6z"/></svg>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="uk-footer">
      <span>© 2026 Melini · Tous droits réservés</span>
      <span>Chaussée d'Alsemberg 817, 1180 Uccle · 02 377 78 80</span>
    </footer>
  );
}

Object.assign(window, { Nav, Hero, Bandeau, About, Collection, Marques, Testimonials, Social, Contact, Footer });
