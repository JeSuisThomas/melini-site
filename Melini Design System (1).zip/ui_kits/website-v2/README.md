# Melini — UI Kit · Site v2 (édition raffinée)

Évolution esthétique du site v1, sans tout changer. Tous les tokens (palette, typo, easings) sont conservés à l'identique. SEO préservé : balises sémantiques, meta complète, JSON-LD LocalBusiness.

## Améliorations apportées

**Hero**
- Composition en deux colonnes : titre éditorial à gauche, "Aujourd'hui" (horaires du jour) à droite — utile pour la cliente qui se demande "c'est ouvert ?"
- Sous-titre serif italique (au lieu d'un overline tout caps) — plus chaleureux
- Marqueurs verticaux "Uccle · 2016" / "Maisons européennes" sur les bords — détail premium type magazine
- Léger zoom de l'image au chargement (18s, ease-out)
- Téléphone affiché directement à côté du CTA principal

**Bandeau**
- Filets décoratifs avant/après le texte

**About**
- Index romain (I, II, III…) pour rythmer les sections — touche éditoriale
- Lead paragraph en serif italique 22px avec **drop cap** rosé
- Photo d'Anjel avec **étiquette flottante** "Anjel, fondatrice" (capsule blanche en relief)
- Stats avec border-top crème, chiffres italiques rosés sur noir

**Collection**
- Disclaimer transformé en encadré crème avec filets ornés (avant/après)
- Carrousel **rythmé** (items légèrement décalés en Y, 3-pattern) — moins plat, plus éditorial
- CTA précédé d'une accroche italique "Le reste vous attend Chaussée d'Alsemberg."

**Interlude pleine largeur** (nouveau)
- Bandeau image 21:9 entre Collection et Marques — *"Pousser la porte, c'est prendre le temps."*
- Aère la page, donne un repos visuel après le carrousel, renforce le storytelling

**Marques**
- Filets verticaux haut/bas (1px rosé, 40px) — section délimitée
- Titre italique en plus de l'eyebrow, ligne serif plus grande
- Mention "Premium · 100 — 200 €" en bas (positionnement clair)

**Témoignages**
- Footer de carte avec **avatar initiale** rosé italique + cite + source — plus humain
- Border-top crème entre citation et auteur

**Contact**
- Composition asymétrique 1.05fr / 1fr
- Lead italique chaleureux *"Le mieux pour vous conseiller, c'est encore de pousser la porte."*
- Info en grid 2 colonnes (adresse + téléphone côte-à-côte, horaires en pleine largeur)
- Téléphone en serif italique 22px (typographique, pas un bloc générique)
- Map placeholder enrichie : 2 routes croisées, **pulse animé** sous le pin, étiquette "Chaussée d'Alsemberg 817" sur le pin

**Footer**
- Grid 3 colonnes avec **monogramme M** italique au centre — signature

## Composants exportés

| Component | Rôle |
|---|---|
| `<NavV2 />` | Pilule glass + monogramme M + wordmark, underline rose au hover |
| `<HeroV2 />` | Hero éditorial split, marqueurs verticaux, téléphone visible |
| `<BandeauV2 />` | Bandeau rosé orné |
| `<ChapterMark n label />` | Numéro romain en cercle + label |
| `<AboutV2 />` | Histoire avec drop cap + cite flottante |
| `<CollectionV2 />` | Disclaimer encadré + carrousel rythmé |
| `<Interlude />` | Bande image 21:9 avec citation |
| `<MarquesV2 />` | Liste serif avec filets verticaux |
| `<TestimonialsV2 />` | Cartes bezel enrichies (avatar initiale) |
| `<SocialV2 />` | CTA Facebook outline rosé |
| `<ContactV2 />` | Section noire asymétrique, map enrichie |
| `<FooterV2 />` | Grid 3 colonnes avec M central |

## SEO préservé
- `<header>`, `<section>`, `<footer>`, `<nav>` sémantiques
- Meta title, description, OG, JSON-LD LocalBusiness conservés
- Toutes les images ont des `alt` descriptifs
- Pas d'image inutile, lazy-loading possible
