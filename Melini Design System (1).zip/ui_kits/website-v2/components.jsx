/* global React */
const { useState, useEffect } = React;

function NavV2() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <nav className={`v2-nav ${scrolled ? 'scrolled' : ''}`}>
      <a href="#" className="brand">
        <span className="mono">M</span>
        <span className="logo">MELINI</span>
      </a>
      <div className="links">
        <a href="#histoire">Notre histoire</a>
        <a href="#selection">Collection</a>
        <a href="#marques">Marques</a>
        <a href="#contact" className="cta">Nous trouver</a>
      </div>
    </nav>
  );
}

function HeroV2() {
  return (
    <header className="v2-hero">
      <div className="v2-hero-image">
        <img src="../../assets/plante-melini.jpg" alt="Boutique Melini, Uccle" />
      </div>
      <div className="v2-hero-edge left">
        <div className="vline"></div>
        <span className="text">Uccle · 2016</span>
        <div className="vline"></div>
      </div>
      <div className="v2-hero-edge right">
        <div className="vline"></div>
        <span className="text">Maisons européennes</span>
        <div className="vline"></div>
      </div>
      <div className="v2-hero-content">
        <div>
          <p className="v2-hero-meta">Chaussures &amp; sacs femme · Uccle, Bruxelles</p>
          <h1>À chaque pas,<br/><em>votre signature.</em></h1>
          <p className="v2-hero-sub">Une sélection patiente de maisons européennes, chez Anjel, Chaussée d'Alsemberg.</p>
          <div className="v2-hero-actions">
            <a href="#contact" className="v2-hero-btn">Nous rendre visite</a>
            <a href="tel:023777880" className="v2-hero-tel">Téléphone<span className="num">02 377 78 80</span></a>
          </div>
        </div>
        <div className="v2-hero-side">
          <div className="lab">Aujourd'hui</div>
          <div className="val">10h00 — 18h30<br/><span style={{opacity:0.7}}>Mardi à samedi</span></div>
        </div>
      </div>
    </header>
  );
}

function BandeauV2({ children }) {
  return <div className="v2-bandeau">{children}</div>;
}

function ChapterMark({ n, label }) {
  return (
    <div className="v2-chapter">
      <span className="num">{n}</span>
      <span className="lab">{label}</span>
    </div>
  );
}

function AboutV2() {
  return (
    <section className="v2-section" id="histoire">
      <div className="v2-about">
        <div className="v2-about-image-wrap">
          <div className="v2-about-image">
            <img src="../../assets/anjel-chaussure.jpg" alt="Anjel, fondatrice de Melini" />
          </div>
          <div className="v2-about-cite">Anjel, fondatrice</div>
        </div>
        <div className="v2-about-body">
          <ChapterMark n="I" label="Notre histoire" />
          <h2 className="v2-title">Melini, c'est avant tout<br/>l'histoire d'<em>Anjel</em>.</h2>
          <p className="lead">Passionnée depuis toujours, Anjel consacre sa vie à l'art de bien chausser les femmes.</p>
          <p>Formée au sein d'enseignes prestigieuses, elle a cultivé l'amour des belles matières, des coupes impeccables et du détail qui fait toute la différence.</p>
          <p>En 2016, elle ouvre Melini sur la Chaussée d'Alsemberg — un espace chaleureux pensé pour le contact humain, loin des codes froids de la vente traditionnelle. Chaque modèle, chaque accessoire a été méticuleusement sélectionné par ses soins.</p>
          <div className="v2-stats">
            <div className="v2-stat"><div className="num"><em>40</em></div><div className="lab">Années d'expérience</div></div>
            <div className="v2-stat"><div className="num"><em>20</em>+</div><div className="lab">Maisons européennes</div></div>
            <div className="v2-stat"><div className="num"><em>2016</em></div><div className="lab">Ouverture à Uccle</div></div>
          </div>
        </div>
      </div>
    </section>
  );
}

function CollectionV2() {
  const seeds = ['shoe1','shoe2','bag1','shoe3','shoe4','bag2','shoe5','shoe6','bag3','shoe7','shoe8','shoe9'];
  const items = [...seeds, ...seeds];
  const [paused, setPaused] = useState(false);
  return (
    <section className="v2-section v2-collection" id="selection">
      <div className="v2-collection-head">
        <ChapterMark n="II" label="Collection" />
        <h2 className="v2-title">Un aperçu, et seulement un aperçu, <em>de nos collections.</em></h2>
      </div>
      <div className="v2-collection-disclaimer">
        Cette sélection ne représente qu'une partie de nos articles en boutique. Venez nous rendre visite pour découvrir l'ensemble de la collection.
      </div>
      <div className="v2-carousel-wrap">
        <div className={`v2-carousel ${paused ? 'paused' : ''}`}
             onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
          {items.map((s, i) => (
            <div key={i} className="v2-carousel-item">
              <div className="v2-carousel-img">
                <img src={`https://picsum.photos/seed/melini-v2-${s}-${i}/280/380`} alt="" />
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="v2-collection-cta">
        <p className="hint">Le reste vous attend Chaussée d'Alsemberg.</p>
        <a href="#contact" className="v2-cta-primary">Découvrir la collection en boutique</a>
      </div>
    </section>
  );
}

function Interlude() {
  return (
    <div className="v2-interlude">
      <img src="../../assets/plante-melini.jpg" alt="Intérieur de la boutique Melini" />
      <p className="caption">Pousser la porte, c'est prendre le temps.</p>
    </div>
  );
}

function MarquesV2() {
  const list = ['NeroGiardini','Hispanitas','Gabor','Unisa','Liu Jo','Etrier','Regarde le Ciel','Tamaris','Ángel Alarcón','Les Tropéziennes','Pedro Miralles','Scapa','Noa Harmon','Sun68','Oh My Sandals','Hee','DLS','Kaotiko','Wirth','Shepherd','Victoria'];
  return (
    <section className="v2-section v2-marques" id="marques">
      <p className="v2-marques-eyebrow">Chapitre III · Nos marques</p>
      <p className="v2-marques-title">Plus de vingt maisons européennes,<br/>sélectionnées avec exigence.</p>
      <p className="v2-marques-line">
        {list.map((m, i) => (
          <span key={m}>
            <span>{m}</span>
            {i < list.length - 1 && <span className="sep">·</span>}
          </span>
        ))}
      </p>
      <p className="v2-marques-count">Premium · 100 — 200 €</p>
    </section>
  );
}

function TestimonialsV2() {
  const items = [
    { q: "Je recommande cette boutique les yeux fermés ! On y trouve un très beau choix de chaussures et d'articles de maroquinerie de qualité. L'accueil est chaleureux et les conseils toujours professionnels.", n: "Nadine V.", s: "Avis Facebook", i: "N" },
    { q: "Il m'a été rare de vivre un accueil aussi chaleureux ! Je suis sortie de la boutique d'Anjel avec LE sac idéal. Merci pour vos précieux conseils.", n: "Ada W.", s: "Avis Google", i: "A" },
    { q: "J'y retourne car la dame est extrêmement soucieuse de la satisfaction du client. Ma fille y vient pour la qualité des chaussures et les conseils.", n: "G.H.", s: "Avis Google", i: "G" },
  ];
  return (
    <section className="v2-section v2-testi">
      <div className="v2-testi-head">
        <ChapterMark n="IV" label="Ce qu'elles en disent" />
        <h2 className="v2-title">La parole à <em>nos clientes.</em></h2>
        <p>De vraies clientes, de vrais avis.</p>
      </div>
      <div className="v2-testi-grid">
        {items.map((t) => (
          <div key={t.n} className="v2-testi-card">
            <div className="v2-testi-inner">
              <blockquote>{t.q}</blockquote>
              <div className="v2-testi-foot">
                <div className="v2-testi-init">{t.i}</div>
                <div className="v2-testi-meta">
                  <cite>{t.n}</cite>
                  <span className="src">{t.s}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function SocialV2() {
  return (
    <section className="v2-section v2-social">
      <ChapterMark n="V" label="Suivez-nous" />
      <h2 className="v2-title">Retrouvez Melini sur <em>Facebook</em>.</h2>
      <p>Nouveautés, coups de coeur et coulisses de la boutique.</p>
      <a href="#" className="v2-social-link">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
        Melini sur Facebook
      </a>
    </section>
  );
}

function ContactV2() {
  return (
    <section className="v2-contact" id="contact">
      <div className="v2-contact-inner">
        <div>
          <ChapterMark n="VI" label="Nous trouver" />
          <h2 className="v2-title">Rendez-nous <em>visite.</em></h2>
          <p className="v2-contact-lead">Le mieux pour vous conseiller, c'est encore de pousser la porte.</p>
          <div className="v2-contact-info">
            <div className="v2-contact-block">
              <h4>Adresse</h4>
              <p><a href="#">Chaussée d'Alsemberg 817<br/>1180 Uccle, Bruxelles</a></p>
            </div>
            <div className="v2-contact-block">
              <h4>Téléphone</h4>
              <a href="tel:023777880" className="tel">02 377 78 80</a>
            </div>
            <div className="v2-contact-block" style={{gridColumn: '1 / -1'}}>
              <h4>Horaires d'ouverture</h4>
              <table className="v2-horaires"><tbody>
                <tr><td>Lundi</td><td>14h00 · 18h30</td></tr>
                <tr><td>Mardi à samedi</td><td>10h00 · 18h30</td></tr>
                <tr><td>Dimanche</td><td>Fermé</td></tr>
              </tbody></table>
            </div>
          </div>
          <div className="v2-contact-actions">
            <a href="#" className="v2-cbtn v2-cbtn-pri">
              <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
              Appeler la boutique
            </a>
            <a href="#" className="v2-cbtn v2-cbtn-sec">
              <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
              Itinéraire Google
            </a>
          </div>
        </div>
        <div className="v2-contact-map">
          <div className="grid"></div>
          <div className="road2"></div>
          <div className="road"></div>
          <div className="pin-pulse"></div>
          <div className="pin-wrap">
            <span className="pin-tag">Chaussée d'Alsemberg 817</span>
            <svg width="36" height="36" fill="#D4A99A" viewBox="0 0 24 24"><path d="M12 2C7.6 2 4 5.6 4 10c0 5.5 8 12 8 12s8-6.5 8-12c0-4.4-3.6-8-8-8zm0 11a3 3 0 110-6 3 3 0 010 6z"/></svg>
          </div>
        </div>
      </div>
    </section>
  );
}

function FooterV2() {
  return (
    <footer className="v2-footer">
      <span className="left">© 2026 Melini · Mentions légales</span>
      <span className="center">M</span>
      <span className="right">Chaussée d'Alsemberg 817 · 1180 Uccle</span>
    </footer>
  );
}

Object.assign(window, { NavV2, HeroV2, BandeauV2, AboutV2, CollectionV2, Interlude, MarquesV2, TestimonialsV2, SocialV2, ContactV2, FooterV2 });
