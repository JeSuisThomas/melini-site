# Melini — Design System

> *"Chaque cliente & chaque pied sont uniques."*

Système de design pour **Melini**, boutique indépendante de chaussures et sacs femme, Chaussée d'Alsemberg 817, 1180 Uccle (Bruxelles). Marques européennes premium (NeroGiardini, Hispanitas, Gabor, Liu Jo, Pedro Miralles…). Fourchette 100–200 €. 40 ans d'expérience d'Anjel, fondatrice. Site ouvert en 2016.

L'objectif #1 du site : **faire venir les clientes en boutique**. Ce n'est pas un e-commerce. C'est une vitrine éditoriale qui crée le lien émotionnel et donne envie de pousser la porte.

## Sources & contexte

- **Repo source de vérité** : [github.com/JeSuisThomas/melini-site](https://github.com/JeSuisThomas/melini-site) (branche `main`)
- **CLAUDE.md** du repo : direction artistique, copy, contraintes (vouvoiement, pas de prix, disclaimer obligatoire)
- **style.css** du repo : tokens et composants — j'ai recopié la palette, les easings et les rayons à l'identique
- **Photos boutique** : `assets/plante-melini.jpg`, `assets/anjel-chaussure.jpg`, `assets/melini-store.jpg`

## Index du système

| Fichier | Quoi |
|---|---|
| `colors_and_type.css` | Variables CSS (couleurs, type, easings, radius, spacing) + sélecteurs de base |
| `tokens.css` | Composants atomiques : boutons, bandeau, cartes double-bezel, disclaimer |
| `assets/` | Photos brutes de la boutique, logo SVG, logos marques |
| `preview/` | Cartes du Design System (palette, type, composants) |
| `ui_kits/website/` | Recréation haute fidélité du site Melini (composants JSX + index interactif) |
| `SKILL.md` | Manifest Claude Skill — pour réutiliser le système ailleurs |

## CONTENT FUNDAMENTALS — comment on écrit chez Melini

**Vouvoiement chaleureux, jamais distant.** On parle comme une amie qui conseille, pas comme un site marketing. Le ton est sobre, précis, jamais clinquant.

**Casing :** Phrase case partout. Les "labels" en petites capitales très espacées (`letter-spacing: 4px`) — c'est la signature typographique de la marque. JAMAIS de TITLE CASE americain.

**Personnes :**
- "vous" pour s'adresser à la cliente (jamais "tu")
- "nous" pour parler de la boutique
- Le prénom **Anjel** est central — c'est un personnage, pas une fonction

**Pas d'emoji. Pas de jargon marketing.** Pas de "découvrez maintenant", "exclusif", "incontournable". On dit "Venez nous rendre visite", "Pousser la porte", "Prendre le temps".

**Vocabulaire signature :**
- "À chaque pas, votre signature" (titre hero)
- "Chaque cliente & chaque pied sont uniques" (baseline)
- "Pousser la porte"
- "Le regard bienveillant et expert d'Anjel"
- "Méticuleusement sélectionné"
- "Conseil personnalisé"
- "Marques européennes premium"

**Ponctuation :** Le **·** (middot, U+00B7) sépare les fragments à la place de la virgule dans les overlines. Exemples : `Uccle · Bruxelles`, `14h00 · 18h30`, `Chaussures & sacs femme`.

**Heures :** format `14h00 · 18h30` (avec `h`, sans `:`, séparées par middot).

**Témoignages :** uniquement de **vrais avis** (Google, Facebook). Jamais inventés. Format : citation italique serif → prénom + initiale → source en très petit.

**Règles absolues :**
- Ne **jamais** afficher de prix
- **Toujours** afficher le disclaimer avant le carrousel collection
- Chaque section doit pousser vers la visite physique

## VISUAL FOUNDATIONS

### Couleurs
Palette nude rosé sur noir profond + crème. Très peu d'accents. Le rosé `#D4A99A` est le seul accent autorisé, le `--rose-light` `#E8C4B8` ajoute du chaleur dans les italiques et survol.

| Token | Hex | Usage |
|---|---|---|
| `--noir` | `#1A1A1A` | Texte principal, fond contact, CTA primary |
| `--blanc` | `#FFFFFF` | Fond, texte sur noir |
| `--rose` | `#D4A99A` | Accent — eyebrows, hairline, hover, bandeau |
| `--rose-light` | `#E8C4B8` | Italique éditorial, états doux |
| `--creme` | `#F5EDE8` | Fond chaleureux secondaire (about, marques) |
| `--creme-deep` | `#EDE0D8` | Séparateurs |
| `--text-body` | `#4A3F3A` | Corps de texte |
| `--text-muted` | `#7A6B63` | Légendes, citations |

### Type
- **Cormorant Garamond** (serif, weight 300 + italique) → titres, blockquotes, horaires en valeur (`16px`), wordmark
- **Outfit** (sans, weight 200/300/400/500) → corps, eyebrows, boutons, labels

Letter-spacing est l'élément le plus identifiable : `4px` sur les eyebrows, `5px` sur le wordmark, `2-3px` sur les overlines. Tout ce qui est en majuscules respire.

### Backgrounds
- Fond principal **blanc**, alterné avec **crème** `#F5EDE8` pour rythmer (about, marques, social).
- Section contact en **noir** profond — c'est l'ancre finale.
- **Hero plein écran cinématique** : photo en `object-fit: cover`, double overlay gradient noir bottom→top + top, texte blanc en bas à gauche.
- **Pas de gradient fluo, pas d'image stock générique.** Toute imagerie est de la boutique réelle.

### Animations
- Toutes les transitions utilisent `cubic-bezier(0.32, 0.72, 0, 1)` (`--ease-premium`) — cinématique, élégant, jamais bouncy
- Durées 400–900ms (long mais maîtrisé)
- **Scroll reveal** (`IntersectionObserver`) avec offset translate-Y de 32px et delays cascade 0.12 / 0.24 / 0.36 / 0.48s
- **Carrousel infini** 50s linear, pause au hover
- **Hairline** rose qui pulse en `scaleX` (2.2s)

### Hover & press
- Hover principal = changement de **fond** (noir → rose, blanc → rose-light), pas de glow ni shadow
- Press : `transform: scale(0.97)` partout (tactile, premium)
- Carrousel et about-image : zoom subtil `scale(1.04 → 1.06)` sur 800–1200ms

### Borders, shadows
- **Bordures** : majoritairement absentes. Quand présentes, hairline 1px en `--creme-deep` ou `rgba(212, 169, 154, 0.15)`.
- **Shadows** : extrêmement discrètes. La nav scrollée a `0 8px 32px rgba(26,26,26,0.06)`. Témoignages utilisent `inset 0 1px 1px rgba(255,255,255,0.8)` pour creuser légèrement.

### Transparence & blur
- **Nav glass** : avant scroll `rgba(255,255,255,0.12)` + `backdrop-filter: blur(24px)` ; après scroll, opaque `rgba(255,255,255,0.92)`. Transition 500ms.
- **Mobile menu** : `rgba(255,255,255,0.96)` + `blur(40px)`.
- Sur fond noir, le texte module via alpha (0.85 / 0.70 / 0.45).

### Layout
- **Nav flottante en pilule centrée** — pattern signature, max 820px, top 20px
- Sections : padding `clamp(80px, 10vw, 140px) clamp(24px, 6vw, 80px)`
- About en **grid 5fr / 6fr** (texte plus large que photo)
- Témoignages : grid 3 colonnes, pile sur mobile
- Contact : grid 2 colonnes 50/50, info à gauche / map à droite

### Corner radii
| Usage | Valeur |
|---|---|
| Boutons, nav, badges | `100px` (capsule) |
| Carrousel items | `1.25rem` |
| Témoignages (bezel) | `1.5rem` extérieur, `calc(1.5rem - 6px)` intérieur |
| About image | `2rem` |
| Map | `1.25rem` |

### Cards — la "double-bezel"
Témoignages : carte crème de 6px → carte blanche intérieure → contenu. Le décalage de 6px crée un cadre doux. Bordure `1px rgba(212,169,154,0.15)`. Pas de shadow externe, juste un `inset` blanc.

### Color vibe des images
Photos de la boutique : **chaud, terreux**, lumière naturelle, pas de filtre froid. La map Google est filtrée `grayscale(0.3) brightness(0.95)` pour s'intégrer dans l'esthétique.

## ICONOGRAPHY

Le site source utilise **très peu d'icônes** — c'est cohérent avec le ton éditorial.

**Approche :** SVG inline, stroke 2px, taille 16–18px, `currentColor` (héritent leur couleur du contexte). Pas d'icon font. Pas de PNG. Pas d'emoji, jamais.

**Icônes utilisées dans le site :**
- **Téléphone** (handset) — bouton "Appeler"
- **Pin Maps** (goutte + cercle) — bouton "Itinéraire"
- **Logo Facebook** — bouton réseaux sociaux
- **Hamburger** — 3 lignes 22×1.5px, espace 5px (mobile nav)
- **Close** (×) — caractère unicode `&times;` dans le mobile menu

**Substitution recommandée pour étendre le set :** [Lucide](https://lucide.dev) (stroke 2px, identique au style maison). Importer via CDN si besoin de plus d'icônes.

```html
<script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
```

**Caractères unicode utilisés comme glyphes :**
- `·` (U+00B7) — séparateur dans les overlines
- `&` (esperluette) — toujours typographié, jamais "et" écrit dans les titres
- `&times;` — close button
- `\201C` (`"`) — guillemets ouvrant en CSS pour les citations (taille 52px, opacity 0.4, rosé)

**Logos marques** : non disponibles dans le repo source. Ils sont rendus en simple texte serif italique sur fond crème dans la section "Marques", séparés par `·`. C'est un choix délibéré (sobre, jamais clinquant).

**Logo Melini** : purement typographique. `Cormorant Garamond` 400, `letter-spacing: 5px`, en majuscules. Pas de symbole, pas de monogramme. Voir `assets/melini-wordmark.svg`.

## Caveats & substitutions

- **Polices** : Cormorant Garamond et Outfit sont chargées via Google Fonts (URL identique au site live). Aucun fichier `.ttf` à embarquer.
- **Logos marques** : aucun fichier source. Sur les écrans de démo j'utilise du texte (cohérent avec le site live).
- **Photos produits** : le site live utilise `picsum.photos` en placeholder. J'ai gardé le même placeholder pour le UI kit — à remplacer par de vraies photos boutique le moment venu.
